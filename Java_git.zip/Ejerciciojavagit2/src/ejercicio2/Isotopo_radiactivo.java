package ejercicio2;
import  java.util.Scanner;

public class Isotopo_radiactivo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		float porcentaje;
		int i;
		long tiempo;
		double mitad = 0,5;
		int resultado;
		
		
		System.out.println("El isotopo esta al 100%");
		System.out.println("Que porcentaje quieres meter");
		porcentaje=scanner.nextFloat();
		while(System.currentTimeMillis()-tiempo)<26*60*1000)) 
			
		

		System.out.println("Tardaria en descomponerse hasta ese porcentaje"+tiempo);
		
	}

}
